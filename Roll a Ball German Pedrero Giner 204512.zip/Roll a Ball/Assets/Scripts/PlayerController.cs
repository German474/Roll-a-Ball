﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    public Rigidbody rb;
    public Text countText;
    public Text WinText;

    public float speed;
    private int count;
    private Vector3 velocity;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 20;
        SetCountText();
        WinText.text = "";
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (Input.GetKey(KeyCode.R))
        {
            SceneManager.LoadScene("MainGame");
        }
    }

    void FixedUpdate () {
        float moveH = Input.GetAxis("Horizontal");
        float moveV = Input.GetAxis("Vertical");

        Vector3 move = new Vector3(moveH, 0, moveV);

        velocity = rb.velocity;

        if(velocity.x < speed)
        {
            rb.AddForce(new Vector3(move.x, 0, 0) * speed);
        }
        if(velocity.z < speed)
        {
            rb.AddForce(new Vector3(0,0,move.z) * speed);
        }
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count--;
            SetCountText();
        }

        if (other.gameObject.CompareTag("Bounce"))
        {
            int vel_x = 1, vel_z = 1;

            if(velocity.x > 0)
            {
                vel_x = -1;
            }
            if (velocity.z > 0)
            {
                vel_z = -1;
            }

            rb.AddForce(new Vector3(vel_x * 1000, 0, vel_z * 1000));
        }
    }


    private void SetCountText()
    {
        countText.text = count.ToString() + " objects more";
        if(count < 1)
        {
            WinText.text = "You Win!";
        }
    }


}
